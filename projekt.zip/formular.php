<html>
<head>
<style>
table, tr, td {
  border: 1px solid black;
  border-collapse: collapse;
}
tr, td {
  padding: 5px;
  text-align: left;    
}
</style>
</head>
</html>
<?php

function search_form(){ ?>


    <table style ="width:50%">
        <tr>
            <td>Název knihy</td>
            <td>Polička</td>
        </tr>
    

<?php }

?>