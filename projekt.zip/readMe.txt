//nastaveni uzivatele a hosta phpmyadmin
$localhost = "localhost:/var/run/mysql/mysql.sock";
$username = "root";
$password = "";
$db_name = "databasebooks";

//nastaveni tabulky
nazev tabulky evidenceofbooks
id int auto_increment
nameOfBooks varchar(60)
shelf varchar(6)
