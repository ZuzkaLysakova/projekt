
<form method="POST" action="uloz.php" >
Název knihy: 
<input type="text" name="nazevKnihy" size="60">
Polička: <input type="text" name="policka" size="20">
<input type="submit" value="Uloz">
</form>

<form method="POST" action="najdiPodleNazvu.php">
Najdi knihu podle názvu:
<input type="text" name="nazevKnihy" size="60"></p>
<input type="submit" value="Najdi">
</form>

<form method="POST" action="najdiPodlePolicky.php">
Najdi knihu podle policky:
<input type="text" name="policka" size="20"></p>
<input type="submit" value="Najdi">
</form>

